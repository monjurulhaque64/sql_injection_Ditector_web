jQuery(document).ready(function ($) {
    var threatChart = null;
    var ctx = document.getElementById('sqliThreatChart');

    // Chart.js Setup
    if (ctx && typeof Chart !== 'undefined') {
        threatChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: SQLiSentinelData.chart_labels,
                datasets: [{
                    label: 'Blocked Attacks',
                    data: SQLiSentinelData.chart_counts,
                    borderColor: '#00ffaa',
                    backgroundColor: 'rgba(0, 255, 170, 0.08)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.3,
                    pointBackgroundColor: '#00ffaa'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(255,255,255,0.05)' },
                        ticks: { color: '#64748b', precision: 0 }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#64748b' }
                    }
                }
            }
        });
    }

    // Ping Test
    $('#sqli-test-btn').on('click', function (e) {
        e.preventDefault();
        var $btn = $(this);
        var $status = $('#sqli-api-status');

        $btn.prop('disabled', true).text('Pinging...');
        $status.css('color', '#38bdf8').text('Testing API...');

        $.ajax({
            url: SQLiSentinelData.ajax_url,
            type: 'POST',
            data: {
                action: 'sqli_test_api_connection',
                nonce: SQLiSentinelData.nonce
            },
            success: function (response) {
                $btn.prop('disabled', false).text('Ping Test');
                if (response.success) {
                    $status.css('color', '#00ffaa').text('🟢 ' + response.data.message);
                } else {
                    $status.css('color', '#ff3366').text('🔴 ' + response.data.message);
                }
            },
            error: function () {
                $btn.prop('disabled', false).text('Ping Test');
                $status.css('color', '#ff3366').text('🔴 Error');
            }
        });
    });

    // Real-Time Dynamic Auto Polling (Every 3 Seconds)
    function fetchLiveStats() {
        $.ajax({
            url: SQLiSentinelData.ajax_url,
            type: 'POST',
            data: {
                action: 'sqli_get_live_stats',
                nonce: SQLiSentinelData.nonce
            },
            success: function (response) {
                if (response.success) {
                    $('#sqli-total-count').text(response.data.total);
                    $('#sqli-today-count').text(response.data.today);
                    $('#sqli-logs-body').html(response.data.logs);

                    if (threatChart && response.data.chart) {
                        threatChart.data.datasets[0].data = response.data.chart;
                        threatChart.update();
                    }
                }
            }
        });
    }

    // Start 3-Second Polling Loop
    setInterval(fetchLiveStats, 3000);
});
