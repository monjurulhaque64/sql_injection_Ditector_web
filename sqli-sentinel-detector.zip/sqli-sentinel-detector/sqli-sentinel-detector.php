<?php
/**
 * Plugin Name: SQLi Sentinel Threat Detector
 * Plugin URI:  https://sql-injection-detector-4r5w.onrender.com
 * Description: Real-time AI & Rule-based Firewall with Dynamic Live Analytics Dashboard.
 * Version:     3.0.0
 * Author:      Monjurul Haque
 * Author URI:  https://github.com/monjurulhaque64
 * Text Domain: sqli-sentinel
 */

if (!defined('ABSPATH')) {
    exit;
}

// -------------------------------------------------------------------
// ১. প্লাগইন অ্যাক্টিভেশনে ডাইনামিক ডাটাবেজ টেবিল তৈরি
// -------------------------------------------------------------------
register_activation_hook(__FILE__, 'sqli_sentinel_create_log_table');
function sqli_sentinel_create_log_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'sqli_sentinel_logs';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        ip_address varchar(45) NOT NULL,
        payload text NOT NULL,
        user_agent varchar(255) DEFAULT '',
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// -------------------------------------------------------------------
// ২. সাইডবার মেনু এবং অ্যাসেটস এনকিউ
// -------------------------------------------------------------------
add_action('admin_menu', 'sqli_sentinel_add_admin_menu');
function sqli_sentinel_add_admin_menu() {
    add_menu_page(
        'SQLi Sentinel Pro',
        'SQLi Sentinel',
        'manage_options',
        'sqli-sentinel',
        'sqli_sentinel_dashboard_page',
        'dashicons-shield-alt',
        75
    );
}

add_action('admin_enqueue_scripts', 'sqli_sentinel_enqueue_admin_scripts');
function sqli_sentinel_enqueue_admin_scripts($hook) {
    if ($hook !== 'toplevel_page_sqli-sentinel') {
        return;
    }

    wp_enqueue_script('chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', array(), '4.4.0', true);
    wp_enqueue_script(
        'sqli-sentinel-admin-js',
        plugin_dir_url(__FILE__) . 'sqli-sentinel-admin.js',
        array('jquery', 'chart-js'),
        '3.0.0',
        true
    );

    $stats = sqli_sentinel_get_weekly_stats();

    wp_localize_script('sqli-sentinel-admin-js', 'SQLiSentinelData', array(
        'ajax_url'     => admin_url('admin-ajax.php'),
        'nonce'        => wp_create_nonce('sqli_sentinel_nonce'),
        'chart_labels' => $stats['labels'],
        'chart_counts' => $stats['counts']
    ));
}

add_action('admin_init', 'sqli_sentinel_settings_init');
function sqli_sentinel_settings_init() {
    register_setting('sqli_sentinel_group', 'sqli_sentinel_api_url');
    register_setting('sqli_sentinel_group', 'sqli_sentinel_enable_firewall');
    register_setting('sqli_sentinel_group', 'sqli_sentinel_whitelist_ips');
}

// -------------------------------------------------------------------
// ৩. PRO Real-Time Dashboard UI
// -------------------------------------------------------------------
function sqli_sentinel_dashboard_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'sqli_sentinel_logs';

    if (isset($_POST['sqli_clear_logs']) && check_admin_referer('sqli_clear_logs_nonce')) {
        $wpdb->query("TRUNCATE TABLE $table_name");
        echo '<div class="notice notice-success is-dismissible"><p>All threat logs cleared successfully!</p></div>';
    }

    $total_blocked = $wpdb->get_var("SELECT COUNT(*) FROM $table_name") ?: 0;
    $today_blocked = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE DATE(created_at) = CURDATE()") ?: 0;
    $recent_logs   = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC LIMIT 10");

    $api_url   = get_option('sqli_sentinel_api_url', 'https://sql-injection-detector-4r5w.onrender.com/predict');
    $enabled   = get_option('sqli_sentinel_enable_firewall', '1');
    $whitelist = get_option('sqli_sentinel_whitelist_ips', '');
    ?>
    <style>
        .sqli-wrap { font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; background: #0b0f19; color: #e2e8f0; padding: 25px; margin-left: -20px; margin-top: -10px; min-height: calc(100vh - 32px); box-sizing: border-box; }
        .sqli-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(0, 255, 170, 0.2); padding-bottom: 15px; margin-bottom: 25px; flex-wrap: wrap; gap: 10px; }
        .sqli-title { font-size: 22px; font-weight: 800; color: #ffffff; display: flex; align-items: center; gap: 10px; margin: 0; }
        .sqli-title span { color: #00ffaa; }
        .sqli-badge { background: rgba(0, 255, 170, 0.1); color: #00ffaa; border: 1px solid rgba(0, 255, 170, 0.3); padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; }
        
        .sqli-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 25px; }
        .sqli-card { background: #131b2e; border: 1px solid rgba(255,255,255,0.08); border-radius: 10px; padding: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.25); }
        .sqli-card-num { font-size: 36px; font-weight: 800; margin-top: 8px; line-height: 1; }
        .sqli-card-num.red { color: #ff3366; text-shadow: 0 0 10px rgba(255,51,102,0.3); }
        
        .sqli-main-grid { display: grid; grid-template-columns: 2.2fr 1fr; gap: 20px; }
        @media (max-width: 1100px) { .sqli-main-grid { grid-template-columns: 1fr; } }
        
        .sqli-table-responsive { width: 100%; overflow-x: auto; margin-top: 15px; }
        .sqli-table { width: 100%; border-collapse: collapse; text-align: left; }
        .sqli-table th { background: #0f1626; color: #94a3b8; padding: 12px; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; }
        .sqli-table td { padding: 12px; border-top: 1px solid #1e293b; font-size: 13px; font-family: monospace; }
        
        .sqli-input { width: 100%; background: #090d16; border: 1px solid #1e293b; color: #00ffaa; padding: 10px; border-radius: 6px; box-sizing: border-box; font-family: monospace; font-size: 13px; }
        .sqli-btn { background: #00ffaa; color: #0b0f19; font-weight: 700; border: none; padding: 10px 18px; border-radius: 6px; cursor: pointer; transition: 0.2s; font-size: 13px; }
        .sqli-btn:hover { background: #ffffff; box-shadow: 0 0 15px rgba(255,255,255,0.4); }
        .sqli-footer { margin-top: 40px; text-align: center; color: #64748b; font-size: 12px; border-top: 1px solid #1e293b; padding-top: 20px; }
        .sqli-footer a { color: #00ffaa; text-decoration: none; font-weight: 600; }
        
        .pulse-live { display: inline-block; width: 8px; height: 8px; background: #00ffaa; border-radius: 50%; box-shadow: 0 0 8px #00ffaa; animation: pulse 1.5s infinite; margin-right: 5px; }
        @keyframes pulse { 0% { opacity: 0.3; } 100% { opacity: 1; } }
    </style>

    <div class="sqli-wrap">
        <div class="sqli-header">
            <h1 class="sqli-title">🛡️ SENTINEL <span>PRO ENGINE</span></h1>
            <span class="sqli-badge"><span class="pulse-live"></span> REALTIME LIVE DATA v3.0</span>
        </div>

        <!-- Dynamic Metric Cards -->
        <div class="sqli-grid">
            <div class="sqli-card">
                <span style="color:#94a3b8; font-size:11px; font-weight:600; letter-spacing:1px;">TOTAL BLOCKED THREATS</span>
                <div class="sqli-card-num red" id="sqli-total-count"><?php echo esc_html($total_blocked); ?></div>
            </div>
            <div class="sqli-card">
                <span style="color:#94a3b8; font-size:11px; font-weight:600; letter-spacing:1px;">ATTACKS TODAY</span>
                <div class="sqli-card-num red" id="sqli-today-count"><?php echo esc_html($today_blocked); ?></div>
            </div>
            <div class="sqli-card">
                <span style="color:#94a3b8; font-size:11px; font-weight:600; letter-spacing:1px;">FLASK AI ENGINE STATUS</span>
                <div style="margin-top:12px; display:flex; align-items:center; gap:10px;">
                    <button type="button" id="sqli-test-btn" class="sqli-btn" style="padding:6px 12px; font-size:12px;">Ping Test</button>
                    <span id="sqli-api-status" style="font-size:12px; color:#00ffaa; font-weight:600;">Ready</span>
                </div>
            </div>
        </div>

        <!-- Main Workspace -->
        <div class="sqli-main-grid">
            <div>
                <!-- Analytics Chart -->
                <div class="sqli-card" style="margin-bottom:20px;">
                    <span style="color:#94a3b8; font-size:11px; font-weight:600; letter-spacing:1px;">7-DAY ATTACK ANALYTICS</span>
                    <div style="height: 220px; margin-top:15px; position:relative;">
                        <canvas id="sqliThreatChart"></canvas>
                    </div>
                </div>

                <!-- Live Incident Logs Table -->
                <div class="sqli-card">
                    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                        <span style="color:#94a3b8; font-size:11px; font-weight:600; letter-spacing:1px;">LIVE INCIDENT LOGS</span>
                        <form method="post" style="margin:0;">
                            <?php wp_nonce_field('sqli_clear_logs_nonce'); ?>
                            <button type="submit" name="sqli_clear_logs" class="button button-small button-link-delete" onclick="return confirm('Clear all threat logs?')">Clear Logs</button>
                        </form>
                    </div>
                    <div class="sqli-table-responsive">
                        <table class="sqli-table">
                            <thead>
                                <tr>
                                    <th>TIMESTAMP</th>
                                    <th>IP ADDRESS</th>
                                    <th>MALICIOUS PAYLOAD</th>
                                </tr>
                            </thead>
                            <tbody id="sqli-logs-body">
                                <?php if (empty($recent_logs)): ?>
                                    <tr><td colspan="3" style="color:#64748b; text-align:center; padding:20px;">No security threats detected. System is clear!</td></tr>
                                <?php else: ?>
                                    <?php foreach ($recent_logs as $log): ?>
                                        <tr>
                                            <td style="color:#64748b;"><?php echo esc_html(date('H:i:s M d', strtotime($log->created_at))); ?></td>
                                            <td style="color:#38bdf8;"><?php echo esc_html($log->ip_address); ?></td>
                                            <td style="color:#ff3366; word-break:break-all;"><?php echo esc_html($log->payload); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Configuration Sidebar -->
            <div>
                <div class="sqli-card">
                    <span style="color:#94a3b8; font-size:11px; font-weight:600; letter-spacing:1px; display:block; margin-bottom:15px;">FIREWALL ENGINE CONFIG</span>
                    <form action="options.php" method="post">
                        <?php settings_fields('sqli_sentinel_group'); ?>
                        
                        <div style="margin-bottom:15px;">
                            <label style="font-size:12px; color:#cbd5e1; display:block; margin-bottom:5px;">Flask API Endpoint:</label>
                            <input type="url" name="sqli_sentinel_api_url" value="<?php echo esc_attr($api_url); ?>" class="sqli-input" required>
                        </div>

                        <div style="margin-bottom:15px;">
                            <label style="font-size:12px; color:#cbd5e1; display:block; margin-bottom:5px;">IP Whitelist (comma separated):</label>
                            <input type="text" name="sqli_sentinel_whitelist_ips" value="<?php echo esc_attr($whitelist); ?>" placeholder="e.g. 192.168.0.1" class="sqli-input">
                        </div>

                        <div style="margin-bottom:20px;">
                            <label style="font-size:13px; color:#00ffaa; cursor:pointer;">
                                <input type="checkbox" name="sqli_sentinel_enable_firewall" value="1" <?php checked(1, $enabled); ?>> Enable Real-time Auto-block
                            </label>
                        </div>

                        <button type="submit" class="sqli-btn" style="width:100%;">Save Configuration</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="sqli-footer">
            SQLi Sentinel Threat Detector Pro | Developed by <strong><a href="https://github.com/monjurulhaque64" target="_blank">Monjurul Haque</a></strong>
        </div>
    </div>
    <?php
}

// -------------------------------------------------------------------
// ৪. AJAX Real-time Live Data Fetcher Handler
// -------------------------------------------------------------------
add_action('wp_ajax_sqli_get_live_stats', 'sqli_get_live_stats_callback');
function sqli_get_live_stats_callback() {
    check_ajax_referer('sqli_sentinel_nonce', 'nonce');

    global $wpdb;
    $table_name = $wpdb->prefix . 'sqli_sentinel_logs';

    $total_blocked = $wpdb->get_var("SELECT COUNT(*) FROM $table_name") ?: 0;
    $today_blocked = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE DATE(created_at) = CURDATE()") ?: 0;
    $recent_logs   = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC LIMIT 10");

    $logs_html = '';
    if (empty($recent_logs)) {
        $logs_html = '<tr><td colspan="3" style="color:#64748b; text-align:center; padding:20px;">No security threats detected. System is clear!</td></tr>';
    } else {
        foreach ($recent_logs as $log) {
            $logs_html .= '<tr>
                <td style="color:#64748b;">' . esc_html(date('H:i:s M d', strtotime($log->created_at))) . '</td>
                <td style="color:#38bdf8;">' . esc_html($log->ip_address) . '</td>
                <td style="color:#ff3366; word-break:break-all;">' . esc_html($log->payload) . '</td>
            </tr>';
        }
    }

    $weekly_stats = sqli_sentinel_get_weekly_stats();

    wp_send_json_success(array(
        'total'  => $total_blocked,
        'today'  => $today_blocked,
        'logs'   => $logs_html,
        'chart'  => $weekly_stats['counts']
    ));
}

// -------------------------------------------------------------------
// ৫. AJAX API Ping Handler
// -------------------------------------------------------------------
add_action('wp_ajax_sqli_test_api_connection', 'sqli_test_api_connection_callback');
function sqli_test_api_connection_callback() {
    check_ajax_referer('sqli_sentinel_nonce', 'nonce');

    $api_url = get_option('sqli_sentinel_api_url', 'https://sql-injection-detector-4r5w.onrender.com/predict');
    
    $start = microtime(true);
    $response = wp_remote_post($api_url, array(
        'timeout' => 5,
        'headers' => array('Content-Type' => 'application/json'),
        'body'    => json_encode(array('input' => "SELECT * FROM test;")),
    ));
    $latency = round((microtime(true) - $start) * 1000);

    if (is_wp_error($response)) {
        wp_send_json_error(array('message' => 'API Offline'));
    }

    $status_code = wp_remote_retrieve_response_code($response);
    if ($status_code === 200) {
        wp_send_json_success(array('message' => "ONLINE ({$latency}ms)"));
    } else {
        wp_send_json_error(array('message' => "HTTP {$status_code} Error"));
    }
}

// -------------------------------------------------------------------
// ৬. Dynamic Live Firewall Inspector Engine
// -------------------------------------------------------------------
add_action('init', 'sqli_sentinel_firewall_inspect', 1);
function sqli_sentinel_firewall_inspect() {
    $firewall_enabled = get_option('sqli_sentinel_enable_firewall', '1');
    if (!$firewall_enabled) {
        return;
    }

    // ক্লায়েন্টের প্রকৃত IP সনাক্ত করার জন্য হেলপার ফাংশন
function sqli_sentinel_get_user_ip() {
    $ip_headers = array(
        'HTTP_CF_CONNECTING_IP', // Cloudflare IP
        'HTTP_X_FORWARDED_FOR',  // Proxy / Load Balancer IP
        'HTTP_CLIENT_IP',
        'HTTP_X_REAL_IP',
        'REMOTE_ADDR'            // Standard IP
    );

    foreach ($ip_headers as $header) {
        if (!empty($_SERVER[$header])) {
            $ip_list = explode(',', $_SERVER[$header]);
            $ip = trim($ip_list[0]); // একাধিক IP থাকলে প্রথমটি (Client IP) নিবে
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }

    return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
}
    
    // IP Whitelist Check
    $whitelist_raw = get_option('sqli_sentinel_whitelist_ips', '');
    if (!empty($whitelist_raw)) {
        $whitelisted_ips = array_map('trim', explode(',', $whitelist_raw));
        if (in_array($user_ip, $whitelisted_ips, true)) {
            return; 
        }
    }

    $inputs = array_merge($_GET, $_POST);

    foreach ($inputs as $key => $value) {
        // Skip administrative non-malicious ajax or admin system fields
        if (in_array($key, array('action', '_wpnonce', 'option_page', 'sqli_sentinel_api_url'), true)) {
            continue;
        }

        if (is_string($value) && strlen(trim($value)) > 2) {
            if (sqli_sentinel_scan_input($value)) {
                
                // Save to Database Table
                global $wpdb;
                $table_name = $wpdb->prefix . 'sqli_sentinel_logs';
                $wpdb->insert($table_name, array(
                    'ip_address' => $user_ip,
                    'payload'    => $value,
                    'user_agent' => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 250)
                ));

                $ref_id = strtoupper(substr(md5(uniqid(rand(), true)), 0, 10));
                $current_time = date('Y-m-d H:i:s T');

                // Render 403 Response Screen
                header("HTTP/1.1 403 Forbidden");
                echo '<!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>403 Access Denied // Sentinel Firewall</title>
                    <style>
                        * { box-sizing: border-box; margin: 0; padding: 0; }
                        body { background-color: #030712; color: #f8fafc; font-family: "JetBrains Mono", Consolas, monospace; display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 20px; }
                        .block-box { background: rgba(15, 23, 42, 0.95); border: 1px solid rgba(255, 51, 102, 0.4); box-shadow: 0 0 40px rgba(255, 51, 102, 0.2); max-width: 600px; width: 100%; border-radius: 12px; padding: 35px; text-align: left; }
                        .badge { display: inline-block; background: rgba(255, 51, 102, 0.15); color: #ff3366; border: 1px solid rgba(255, 51, 102, 0.4); padding: 4px 12px; border-radius: 4px; font-size: 11px; letter-spacing: 2px; font-weight: bold; }
                        h1 { font-size: 22px; color: #ffffff; margin: 20px 0 10px 0; font-weight: 800; }
                        p { color: #94a3b8; font-size: 13px; line-height: 1.6; }
                        .meta-table { width: 100%; border-collapse: collapse; margin-top: 20px; background: rgba(3, 7, 18, 0.7); border-radius: 8px; overflow: hidden; border: 1px solid #1e293b; }
                        .meta-table td { padding: 10px 14px; font-size: 12px; border-bottom: 1px solid #1e293b; color: #cbd5e1; word-break: break-all; }
                        .meta-table td.label { color: #64748b; font-weight: 600; width: 130px; }
                        .footer { margin-top: 25px; font-size: 12px; color: #475569; text-align: center; }
                        .footer strong { color: #00ffaa; }
                    </style>
                </head>
                <body>
                    <div class="block-box">
                        <span class="badge">403 SECURITY THREAT DETECTED</span>
                        <h1>SQL Injection Blocked!</h1>
                        <p>Your request was flagged and neutralized by <strong>SQLi Sentinel Firewall</strong> as a potential SQL Injection attack.</p>
                        
                        <table class="meta-table">
                            <tr><td class="label">INCIDENT REF:</td><td style="color:#ff3366; font-weight:bold;">#' . $ref_id . '</td></tr>
                            <tr><td class="label">CLIENT IP:</td><td>' . esc_html($user_ip) . '</td></tr>
                            <tr><td class="label">TIMESTAMP:</td><td>' . $current_time . '</td></tr>
                            <tr><td class="label">PROTECTION:</td><td>Rule Engine + AI ML Sentinel</td></tr>
                        </table>

                        <div class="footer">
                            Powered by SQLi Sentinel Firewall | Developed by <strong>Monjurul Haque</strong>
                        </div>
                    </div>
                </body>
                </html>';
                exit;
            }
        }
    }
}

function sqli_sentinel_scan_input($input_string) {
    $api_url = get_option('sqli_sentinel_api_url', 'https://sql-injection-detector-4r5w.onrender.com/predict');

    $response = wp_remote_post($api_url, array(
        'method'      => 'POST',
        'timeout'     => 4,
        'headers'     => array('Content-Type' => 'application/json'),
        'body'        => json_encode(array('input' => $input_string)),
    ));

    if (is_wp_error($response)) {
        return false;
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    return isset($body['result']) && $body['result'] === 'malicious';
}

function sqli_sentinel_get_weekly_stats() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'sqli_sentinel_logs';

    $labels = array();
    $counts = array();

    for ($i = 6; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime("-$i days"));
        $labels[] = date('M d', strtotime("-$i days"));

        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE DATE(created_at) = %s",
            $date
        ));
        $counts[] = intval($count);
    }

    return array('labels' => $labels, 'counts' => $counts);
}
